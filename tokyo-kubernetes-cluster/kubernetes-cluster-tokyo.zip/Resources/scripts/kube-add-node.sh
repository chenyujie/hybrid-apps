#!/bin/bash

# $1 - file path

/opt/bin/kubectl create -f $1
